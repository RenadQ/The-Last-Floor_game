import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  fill: { flex: 1 },
  center: { justifyContent: 'center', alignItems: 'center' },
});

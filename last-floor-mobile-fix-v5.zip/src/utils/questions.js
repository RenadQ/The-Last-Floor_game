export const ELEVATOR_QUESTION_COINS = 10;

export const ELEVATOR_QUESTIONS = [
  { question: 'The more you take, the more you leave behind. What are they?', options: ['Footsteps', 'Keys', 'Coins', 'Ghosts'], correctAnswer: 'Footsteps' },
  { question: 'What can travel around the world while staying in one corner?', options: ['A stamp', 'A map', 'An echo', 'A shadow'], correctAnswer: 'A stamp' },
  { question: 'What gets wetter as it dries?', options: ['A towel', 'A sponge', 'A cloud', 'A river'], correctAnswer: 'A towel' },
  { question: 'I have cities but no houses, mountains but no trees, and water but no fish. What am I?', options: ['A map', 'A dream', 'A book', 'A mirror'], correctAnswer: 'A map' },
  { question: 'What has many keys but cannot open a single lock?', options: ['A piano', 'An elevator', 'A keyboard', 'A chest'], correctAnswer: 'A piano' },
  { question: 'What belongs to you but other people use it more than you do?', options: ['Your name', 'Your coins', 'Your phone', 'Your shadow'], correctAnswer: 'Your name' },
  { question: 'What is so fragile that saying its name breaks it?', options: ['Silence', 'Glass', 'Ice', 'Fear'], correctAnswer: 'Silence' },
  { question: 'I have hands but I cannot clap. What am I?', options: ['A clock', 'A ghost', 'A statue', 'A puppet'], correctAnswer: 'A clock' },
  { question: 'What can you catch but not throw?', options: ['A cold', 'A coin', 'A key', 'A light'], correctAnswer: 'A cold' },
  { question: 'What has one eye but cannot see?', options: ['A needle', 'A storm', 'A camera', 'A ghost'], correctAnswer: 'A needle' },
  { question: 'What runs but never walks, has a mouth but never talks?', options: ['A river', 'A train', 'A clock', 'A candle'], correctAnswer: 'A river' },
  { question: 'What goes up and never comes down?', options: ['Your age', 'An elevator', 'A balloon', 'Smoke'], correctAnswer: 'Your age' },
];

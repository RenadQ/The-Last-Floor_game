import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import GameScreen, { AchievementsScreen, SettingsScreen } from '../screens/GameScreen';

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Game" component={GameScreen} />
      <Stack.Screen name="Achievements" component={AchievementsScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
    </Stack.Navigator>
  );
}
